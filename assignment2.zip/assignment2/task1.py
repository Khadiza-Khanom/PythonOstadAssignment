def calculation(num1,num2):
    return (num1+num2)/2

result = calculation(2,5)
print(result)

result = calculation(6,5)
print(result)

result = calculation(2,7)
print(result)

result = calculation(3,0)
print(result)

result = calculation(6,1)
print(result)


