
def sorting_list(fruits):
    fruits.sort()
    print(fruits)

fruits = ['apple','cherry','kiwi','grape','banana']

sorting_list(fruits)