
sum=0
for i in range(1,100):
    if i%2==0:
        sum = sum + i
        i+1

print(sum)


