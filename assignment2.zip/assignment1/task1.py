number = int(input('Enter a number here: '))

if number%2==0:
    print("This is an even number")

else:
    print("This is an odd number")